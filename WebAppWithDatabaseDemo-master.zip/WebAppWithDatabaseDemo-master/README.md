# WebAppWithDatabaseDemo
Sample ASP.NET Core MVC app with database for demoing CI-CD pipelines using Azure DevOps (previously VSTS) 

</br>

<table>
  <tr>
    <td>Build status</td>
    <td>Release status - dev</td> 
    <td>Release status - test</td>  
    <td>Release status - prod</td>
  </tr>
  <tr>
    <td>
<img src="https://houssemdellai.visualstudio.com/WebAppWithDatabaseDemo/_apis/build/status/WebAppWithDatabase-CI-mutiphase?branchName=master"/>
    </td>
    <td>
<img src="https://houssemdellai.vsrm.visualstudio.com/_apis/public/Release/badge/7ac88337-9f15-48dd-ab33-a60c7a26e4a5/4/6"/>
  </td>
    <td>
<img src="https://houssemdellai.vsrm.visualstudio.com/_apis/public/Release/badge/7ac88337-9f15-48dd-ab33-a60c7a26e4a5/4/9"/>
    </td>
    <td>
<img src="https://houssemdellai.vsrm.visualstudio.com/_apis/public/Release/badge/7ac88337-9f15-48dd-ab33-a60c7a26e4a5/4/10"/>
  </td>
  </tr>
  </table>
  
  </br>
  
  <a href="http://armviz.io/#/?load=https://raw.githubusercontent.com/HoussemDellai/WebAppWithDatabaseDemo/master/AzureResourceGroupDeployment/WebSiteSQLDatabase.json" target="_blank">
  <img src="http://armviz.io/visualizebutton.png"/>
</a>

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2FHoussemDellai%2FWebAppWithDatabaseDemo%2Fmaster%2FAzureResourceGroupDeployment%2FWebSiteSQLDatabase.json" rel="nofollow">
    <img src="http://azuredeploy.net/deploybutton.png" style="max-width:100%;">
</a>

</br>
      
https://www.youtube.com/watch?v=uVne2HXkWXI&list=PLpbcUe4chE78FEvDjD9zfzSGvsdkvkkrj&index=1
